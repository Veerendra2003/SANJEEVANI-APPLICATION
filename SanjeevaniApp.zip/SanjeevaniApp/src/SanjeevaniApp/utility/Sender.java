
package SanjeevaniApp.utility;


public interface Sender {
    boolean send(String number,String data) throws Exception;
}
