package SanjeevaniApp.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnection {
    private static Connection conn = null;
    static{
        try{
            Class.forName("oracle.jdbc.OracleDriver");
            System.out.println("Driver loaded Successfully");
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
            System.exit(0);
        }
        try{
            conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE", "project","java");
            System.out.println("Connection Open Successfully");
        }
        catch(SQLException e){
            e.printStackTrace();
            System.exit(0);
        }
    }
    public static Connection getConnection(){
        return conn;
    }
    public static void closeConnection(){
        if(conn!=null){
            try{
                conn.close();
                System.out.println("Connection Close Successfully");
            }
            catch(SQLException e){
                e.printStackTrace();
            }
        }
    }
}
