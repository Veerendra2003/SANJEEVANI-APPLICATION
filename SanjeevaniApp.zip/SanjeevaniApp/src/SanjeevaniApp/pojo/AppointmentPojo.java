
package SanjeevaniApp.pojo;

public class AppointmentPojo {

    @Override
    public String toString() {
        return "AppointmentPojo{" + "patientId=" + patientId + ", patientName=" + patientName + ", opd=" + opd + ", status=" + status + ", appointmentDate=" + appointmentDate + ", docotorName=" + docotorName + ", mobileNo=" + mobileNo + '}';
    }

    public AppointmentPojo(String patientId, String patientName, String opd, String status, String appointmentDate, String docotorName, String mobileNo) {
        this.patientId = patientId;
        this.patientName = patientName;
        this.opd = opd;
        this.status = status;
        this.appointmentDate = appointmentDate;
        this.docotorName = docotorName;
        this.mobileNo = mobileNo;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getOpd() {
        return opd;
    }

    public void setOpd(String opd) {
        this.opd = opd;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getDocotorName() {
        return docotorName;
    }

    public void setDocotorName(String docotorName) {
        this.docotorName = docotorName;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }
    private String patientId;
    private String patientName;
    private String opd;
    private String status;
    private String appointmentDate;
    private String docotorName;
    private String mobileNo;
    
    public AppointmentPojo(){
    }
}
