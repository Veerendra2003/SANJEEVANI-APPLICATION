package SanjeevaniApp.pojo;


public class UserProfile {

    public static String getUserId() {
        return UserId;
    }

    public static void setUserId(String UserId) {
        UserProfile.UserId = UserId;
    }

    public static String getUserName() {
        return userName;
    }

    public static void setUserName(String userName) {
        UserProfile.userName = userName;
    }

    public static String getUserType() {
        return userType;
    }

    public static void setUserType(String userType) {
        UserProfile.userType = userType;
    }
    private static String userName;
    private static String UserId;
    private static String userType;

    


}
