package SanjeevaniApp.pojo;

public class ReceptionistPojo {

    public String getReceptioistId() {
        return receptioistId;
    }

    public void setReceptioistId(String receptioistId) {
        this.receptioistId = receptioistId;
    }

    public String getReceptionistName() {
        return receptionistName;
    }

    public void setReceptionistName(String receptionistName) {
        this.receptionistName = receptionistName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
   private String receptioistId;
   private String receptionistName;
   private String gender;
}
